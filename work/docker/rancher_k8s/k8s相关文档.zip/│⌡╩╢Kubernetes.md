# 初始kubernetes

## 组件

1. kube-apiserver，资源操作的唯一入口，提供认证，授权，访问控制、API注册和服务发现等机制
2. ETCD是kubernetes提供默认的存储系统，保存集群数据
3. kube-controller-manager管理控制器，集中处理常规任务的后台线程：
   1. 节点控制器
   2. 副本控制器
   3. 端点控制器，填充endpoints对象（即链接service&pods）
4. kube-scheduler监视新创建没有分配到Node的pod，为pod选择node
5. kubelet负责维护容器的生命周期、volume、网络

